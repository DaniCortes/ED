var annotated_dup =
[
    [ "Cronologia", "classCronologia.html", "classCronologia" ],
    [ "FechaHistorica", "classFechaHistorica.html", "classFechaHistorica" ]
];